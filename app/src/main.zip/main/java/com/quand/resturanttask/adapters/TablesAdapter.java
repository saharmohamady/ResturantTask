package com.quand.resturanttask.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.quand.resturanttask.R;

import java.util.ArrayList;

/**
 * Created by salmohamady on 2/23/2016.
 */
public class TablesAdapter extends RecyclerView.Adapter<TablesAdapter.ViewHolder> {

    private final Context context;
    private ArrayList<Boolean> tablessData = new ArrayList<Boolean>();
private int selectedIndex=-1;
    public TablesAdapter(Context context) {
        this.context = context;
    }

    public TablesAdapter(Context context, ArrayList<Boolean> data) {
        this.context = context;
        this.tablessData = data;
    }

    public void addTable(Boolean newOrder) {
        if (tablessData == null)
            tablessData = new ArrayList<Boolean>();
        tablessData.add(newOrder);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // create a new view
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.table_item_view, parent, false);
        // set the view's size, margins, paddings and layout parameters

        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        Boolean reserved = tablessData.get(position);
        if (reserved) {
            holder.reserved.setVisibility(View.VISIBLE);
        } else
            holder.reserved.setVisibility(View.GONE);
    }

    @Override
    public int getItemCount() {
        return tablessData.size();
    }

    public Boolean getItemAtPostion(int pos) {
        if (tablessData != null)
            return tablessData.get(pos);
        return null;
    }

    public void setReserved(int position) {
        tablessData.set(position,true);
        notifyDataSetChanged();
    }
    public void setUnReserved(int position) {
        tablessData.set(position,false);
        notifyDataSetChanged();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final ImageView reserved;


        // each data item is just a string in this case
        public View layout;

        public ViewHolder(View v) {
            super(v);
            layout = v;
            reserved = (ImageView) v.findViewById(R.id.reserved);
        }
    }

}
