package com.quand.resturanttask.model;

import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by salmohamady on 9/5/2016.
 */
public class Customer implements Parcelable {
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Customer() {

    }

    public Customer(String id, String firstName, String lastName) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public Customer(Parcel in) {
        String[] data = new String[3];

        in.readStringArray(data);
        this.id = data[0];
        this.firstName = data[1];
        this.lastName = data[2];
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeStringArray(new String[]{this.id,
                this.firstName,
                this.lastName,
        });
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
        public Customer createFromParcel(Parcel in) {
            return new Customer(in);
        }

        public Customer[] newArray(int size) {
            return new Customer[size];
        }
    };

    public static ArrayList<Customer> loadFromJson(String jsonArray) {
        ArrayList<Customer> customersList = new ArrayList<>();

        try {
            JSONArray customersArrJson = new JSONArray(jsonArray);
            Customer tempCustomer;
            JSONObject customer;
            for (int i = 0; i < customersArrJson.length(); i++) {
                customer = customersArrJson.getJSONObject(i);
                tempCustomer = new Customer();
                tempCustomer.setId(customer.getString("id"));
                tempCustomer.setFirstName(customer.getString("customerFirstName"));
                tempCustomer.setLastName(customer.getString("customerLastName"));

                customersList.add(tempCustomer);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return customersList;
    }

    private String id;
    private String firstName;
    private String lastName;

    public String getName() {
        return firstName + " " + lastName;
    }
}
